Template.hr.events({
    'submit #hr_form' : function(e, t) {
      e.preventDefault();
      var name1 =t.find('#res_name').value.trim();
      var Answer1=$('input[name=Answer1]:checked').val();
      var Answer2=$('input[name=Answer2]:checked').val();
      var Answer3=$('input[name=Answer3]:checked').val();
      var Answer4=$('input[name=Answer4]:checked').val();
      Meteor.call("Inserthr1", name1, Answer1, Answer2,Answer3,Answer4,
            function(err,res){
               if (err) {
                  alert(err);
               }
               else{
                  alert(res);
               }
               });
      }
 })

 Template.hr.rendered = function () {


   console.log("data1",empid);
$('.toggle-one').bootstrapToggle();
};


employee = new MysqlSubscription('allemployee');

if (Meteor.isClient) {
Template.hr.helpers({
    employee: function () {
          //  console.log("employee",employee);
            emp= employee.reactive();
            console.log("emp",emp);
            return emp;
    }
})
}



