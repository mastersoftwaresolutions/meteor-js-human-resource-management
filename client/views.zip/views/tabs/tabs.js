Template.tabs.helpers({
    employee1: function () {
          //  console.log("employee",employee);
            emp1= empid.reactive();
            console.log("emp",emp1);
            return emp1;
    }
})