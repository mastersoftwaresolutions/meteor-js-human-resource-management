Template.employee.events({
  "click #init_join": function (event, template) {
    event.preventDefault();
    var emp_name =template.find('#ename').value.trim();
    var emp_id = template.find('.'+emp_name).value.trim();
    alert(emp_id);
    alert(emp_name);
     Router.go('tabs',{_id:emp_id});
  }

});
alemployee = new MysqlSubscription('allemployee');

if (Meteor.isClient) {
Template.employee.helpers({
    employee: function () {
            emp= alemployee.reactive();
            console.log("emp",emp);
            return emp;
    }
})
}